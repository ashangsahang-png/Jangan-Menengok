# JANGAN MENENGOK v1.9.3 — APK build dengan ikon khusus

ZIP ini sudah berisi sumber ikon aplikasi di `resources/icon.png`. Workflow GitHub Actions akan membuat aset ikon Android dari gambar ini, lalu membangun debug APK.

## Langkah dari HP Android
1. Ekstrak ZIP ini.
2. Unggah seluruh isi folder ke repository GitHub pada branch `main` atau `master`.
3. Buka tab **Actions**.
4. Pilih **Build JANGAN MENENGOK APK**, lalu tekan **Run workflow**. Workflow juga berjalan saat ada push ke branch tersebut.
5. Jika build sukses, buka hasil workflow dan unduh artifact `JANGAN-MENENGOK-v1.9.3-debug-apk`.
6. Ekstrak artifact dan instal `app-debug.apk`.

Ikon dibuat dari `resources/icon.png`. File APK belum dibuat di ZIP ini; GitHub Actions harus dijalankan agar APK terbentuk.
