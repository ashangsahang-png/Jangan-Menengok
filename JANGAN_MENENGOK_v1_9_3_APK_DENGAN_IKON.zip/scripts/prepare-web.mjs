import fs from 'node:fs';
import path from 'node:path';

const root = process.cwd();
const out = path.join(root, 'www');

fs.rmSync(out, { recursive: true, force: true });
fs.mkdirSync(out, { recursive: true });

for (const name of ['index.html', 'assets']) {
  const from = path.join(root, name);
  if (!fs.existsSync(from)) throw new Error(`Missing required project item: ${name}`);
  fs.cpSync(from, path.join(out, name), { recursive: true });
}

console.log('Prepared local game files in www/');
