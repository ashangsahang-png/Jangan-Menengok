
import * as THREE from 'https://cdn.jsdelivr.net/npm/three@0.160.0/build/three.module.js';
import { GLTFLoader } from 'https://cdn.jsdelivr.net/npm/three@0.160.0/examples/jsm/loaders/GLTFLoader.js';
const status=document.querySelector('#status');
const renderer=new THREE.WebGLRenderer({antialias:true});renderer.setPixelRatio(Math.min(devicePixelRatio,1.7));renderer.setSize(innerWidth,innerHeight);renderer.shadowMap.enabled=true;renderer.outputColorSpace=THREE.SRGBColorSpace;renderer.toneMapping=THREE.ACESFilmicToneMapping;renderer.toneMappingExposure=1.25;document.body.prepend(renderer.domElement);
const scene=new THREE.Scene();scene.background=new THREE.Color(0x11191b);scene.fog=new THREE.Fog(0x11191b,14,65);
scene.add(new THREE.HemisphereLight(0xc9e4ff,0x35312b,2.0));const amb=new THREE.AmbientLight(0xffffff,.75);scene.add(amb);
const playerLight=new THREE.SpotLight(0xfff1ce,55,24,Math.PI/5,.55,1.3);playerLight.castShadow=true;scene.add(playerLight);scene.add(playerLight.target);
const camera=new THREE.PerspectiveCamera(75,innerWidth/innerHeight,.08,180);camera.position.set(0,1.65,5);
let mapRoot=null,collisionRoot=null,ghost=null,ghost2=null,mapReady=false,ghostReady=false,playing=false,flash=true,hidden=false,dead=false,won=false,battery=100,yaw=0,pitch=0,px=0,pz=7;
let lastKnown={x:px,z:pz},searchUntil=0,searchAngle=0,ghostPath=[],pathTimer=0;
const floor=new THREE.Mesh(new THREE.PlaneGeometry(100,100),new THREE.MeshStandardMaterial({color:0x333b3b,roughness:1}));floor.rotation.x=-Math.PI/2;floor.position.y=-.05;floor.receiveShadow=true;scene.add(floor);
function normalizeModel(obj,targetSize){const box=new THREE.Box3().setFromObject(obj);const size=box.getSize(new THREE.Vector3());const max=Math.max(size.x,size.y,size.z)||1;obj.scale.multiplyScalar(targetSize/max);const b2=new THREE.Box3().setFromObject(obj);obj.position.y-=b2.min.y;return new THREE.Box3().setFromObject(obj)}
function fallbackMap(){buildStableMap()}

// Backrooms buatan sendiri: lantai, plafon, dinding kuning dan lorong bercabang.
// Tidak memakai model horror_map yang origin/skalanya membuat objek tertanam.
function buildStableMap(){
 status.textContent='Membangun Backrooms…';
 const visual=new THREE.Group();
 collisionRoot=new THREE.Group();
 const floorMat=new THREE.MeshStandardMaterial({color:0x777064,roughness:1});
 const wallMat=new THREE.MeshStandardMaterial({color:0xc6b96b,roughness:1});
 const ceilingMat=new THREE.MeshStandardMaterial({color:0xb8b6a7,roughness:1});
 const trimMat=new THREE.MeshStandardMaterial({color:0x6c684e,roughness:1});
 function box(w,h,d,x,y,z,mat,collide=true){
   const m=new THREE.Mesh(new THREE.BoxGeometry(w,h,d),mat);
   m.position.set(x,y,z);m.receiveShadow=true;m.castShadow=true;visual.add(m);
   if(collide){const c=new THREE.Mesh(new THREE.BoxGeometry(w,h,d),new THREE.MeshBasicMaterial({visible:false}));c.position.copy(m.position);collisionRoot.add(c)}
   return m;
 }
 // Walkable main floor and ceiling are aligned to player camera (feet y=0).
 box(42,.25,54,0,-.14,-4,floorMat,false);
 box(42,.25,54,0,4.1,-4,ceilingMat,false);
 // Outer bounds
 box(.35,4.2,54,-21,2,-4,wallMat);box(.35,4.2,54,21,2,-4,wallMat);
 box(42,4.2,.35,0,2,-31,wallMat);box(42,4.2,.35,0,2,23,wallMat);
 // Partitions make a large maze with separated areas and openings.
 const walls=[
  [-13,2,-22,.35,18],[-6,2,-25,.35,12],[2,2,-22,.35,18],[12,2,-25,.35,12],
  [-17,2,-13,8,.35],[-9,2,-13,7,.35],[7,2,-14,10,.35],[16,2,-9,10,.35],
  [-13,2,-5,.35,14],[-4,2,-7,.35,16],[5,2,-5,.35,12],[13,2,0,.35,14],
  [-17,2,5,8,.35],[-7,2,4,9,.35],[3,2,7,9,.35],[16,2,10,10,.35],
  [-13,2,15,.35,12],[-3,2,17,.35,10],[8,2,15,.35,12],
  [-17,2,-18,8,.35],[-2,2,-18,7,.35],[9,2,-20,8,.35],
  [-17,2,11,7,.35],[-1,2,-1,8,.35],[9,2,5,8,.35]
 ];
 for(const a of walls)box(a[3],4.2,a[4],a[0],a[1],a[2],wallMat,true);
 // fluorescent lights
 for(let x=-16;x<=16;x+=8)for(let z=-26;z<=18;z+=10){
   const lamp=new THREE.Mesh(new THREE.BoxGeometry(2.3,.07,.65),new THREE.MeshStandardMaterial({color:0xfff1bf,emissive:0xc8bd8a,emissiveIntensity:.7}));
   lamp.position.set(x,3.93,z);visual.add(lamp);
   const light=new THREE.PointLight(0xffe7a3,1.25,9);light.position.set(x,3.6,z);visual.add(light);
 }
 scene.add(visual);scene.add(collisionRoot);mapRoot=visual;mapReady=true;
 // Start player and objects above the floor and inside the maze.
 px=0;pz=19;yaw=Math.PI;
 status.textContent='Backrooms siap. Cari 3 kunci dan temukan EXIT.';
}
buildStableMap();
// Dua musuh dengan animasi dan AI terpisah. Hanako menggantikan Ako; Hikari adalah hantu kedua.
const enemies=[];
function makeEnemy(url,name,startPos,opts={}){
 const enemy={name,root:null,mixer:null,idle:null,walk:null,capture:null,current:null,path:[],pathTimer:0,patrolIndex:0,patrol:opts.patrol||[],speed:opts.speed||2.0,detectRange:opts.detectRange||10,detectAngle:opts.detectAngle||Math.PI*.62,alert:false,searchUntil:0,lastSeen:{x:startPos[0],z:startPos[2]||startPos[1]},ready:false};
 enemies.push(enemy);
 new GLTFLoader().load(url,g=>{
   const obj=g.scene; normalizeModel(obj,opts.size||1.5); obj.position.set(startPos[0],0,startPos[1]);
   obj.traverse(n=>{if(n.isMesh){n.castShadow=true;n.receiveShadow=true;if(n.material){n.material.side=THREE.DoubleSide;n.material.needsUpdate=true}}}); scene.add(obj);enemy.root=obj;
   if(g.animations&&g.animations.length){
     enemy.mixer=new THREE.AnimationMixer(obj);
     const find=(re,exclude)=>g.animations.find(c=>re.test(c.name)&&c!==exclude);
     const idleClip=find(/idle|stand|breath/i)||g.animations[0];
     const walkClip=find(/walk|run|move_ing|locomotion/i,idleClip)||idleClip;
     const capClip=find(/attack_ing|reaction|pickup|attack_start|panic/i,walkClip)||find(/attack|reaction|pickup|panic/i,idleClip)||idleClip;
     enemy.idle=enemy.mixer.clipAction(idleClip);enemy.idle.setLoop(THREE.LoopRepeat);enemy.idle.play();
     enemy.walk=enemy.mixer.clipAction(walkClip);enemy.walk.setLoop(THREE.LoopRepeat);enemy.walk.enabled=true;enemy.walk.setEffectiveWeight(0);
     enemy.capture=enemy.mixer.clipAction(capClip);enemy.capture.setLoop(THREE.LoopOnce);enemy.capture.clampWhenFinished=true;enemy.capture.enabled=true;enemy.capture.setEffectiveWeight(0);
     enemy.current=enemy.idle; enemy.animNames={idle:idleClip.name,walk:walkClip.name,capture:capClip.name};
   }
   enemy.ready=true;
   if(name==='Hanako'){ghost=obj;ghostReady=true;status.textContent='Hanako aktif • patroli dan deteksi player';}
   else status.textContent='Hanako dan Hikari dimuat';
 },undefined,e=>{console.error(name+' GLB error',e);const m=new THREE.Mesh(new THREE.CapsuleGeometry(.38,.95,4,8),new THREE.MeshStandardMaterial({color:opts.color||0xabbcbc}));m.position.set(startPos[0],.95,startPos[1]);scene.add(m);enemy.root=m;enemy.ready=true;if(name==='Hanako'){ghost=m;ghostReady=true;}status.textContent=name+' memakai model cadangan.';});
 return enemy;
}
const hanako=makeEnemy('./assets/Hanako.glb','Hanako',[-18,18],{size:1.5,speed:2.05,detectRange:11,detectAngle:Math.PI*.62,patrol:[[-18,18],[-17,-25],[-5,-24],[5,-16],[17,-20],[17,17],[4,18],[-8,8]]});
const hikari=makeEnemy('./assets/Hikari.glb','Hikari',[18,-26],{size:1.5,speed:1.75,detectRange:8.5,detectAngle:Math.PI*.5,color:0xd6d6ff,patrol:[[18,-26],[8,-24],[5,-14],[16,-8],[16,8],[5,17],[-5,17],[-17,11]]});
const keys=[{x:-17,z:-2},{x:16,z:-17},{x:15,z:18}],got=[false,false,false],keyMeshes=[];
keys.forEach(k=>{let m=new THREE.Mesh(new THREE.TorusGeometry(.19,.055,8,16),new THREE.MeshStandardMaterial({color:0xffd24d,emissive:0x684000,metalness:.5}));m.position.set(k.x,.45,k.z);scene.add(m);keyMeshes.push(m)});
const exit=new THREE.Mesh(new THREE.BoxGeometry(1.8,2.4,.2),new THREE.MeshStandardMaterial({color:0xb51f2b,emissive:0x4b0000}));exit.position.set(0,1,-29.8);scene.add(exit);
const mapC=document.querySelector('#map'),ctx=mapC.getContext('2d');
function drawMap(){ctx.clearRect(0,0,176,240);ctx.fillStyle='#10191c';ctx.fillRect(0,0,176,240);ctx.strokeStyle='#687579';ctx.strokeRect(12,12,152,216);ctx.fillStyle='#ffd24d';keys.forEach((k,i)=>{if(!got[i]){ctx.beginPath();ctx.arc(88+k.x*3.3,120-k.z*3.3,4,0,7);ctx.fill()}});ctx.fillStyle='#f33';ctx.fillRect(88-5,120-29*3.3-3,10,6);enemies.forEach((e,i)=>{if(e.root){ctx.fillStyle=i===0?'#ff5867':'#ff8b45';ctx.beginPath();ctx.arc(88+e.root.position.x*3.3,120-e.root.position.z*3.3,4,0,7);ctx.fill()}});ctx.fillStyle='#4be7f0';ctx.beginPath();ctx.arc(88+px*3.3,120-pz*3.3,4,0,7);ctx.fill();requestAnimationFrame(drawMap)}drawMap();
let move={};function bind(id,k){let b=document.getElementById(id);b.addEventListener('pointerdown',e=>{e.preventDefault();move[k]=true;b.setPointerCapture(e.pointerId)});['pointerup','pointercancel','lostpointercapture'].forEach(ev=>b.addEventListener(ev,()=>move[k]=false))}bind('up','f');bind('down','b');bind('left','l');bind('right','r');
let lastX=null,lastY=null;renderer.domElement.addEventListener('pointerdown',e=>{lastX=e.clientX;lastY=e.clientY});renderer.domElement.addEventListener('pointermove',e=>{if(lastX!==null&&playing){yaw-=(e.clientX-lastX)*.006;pitch=Math.max(-.7,Math.min(.7,pitch-(e.clientY-lastY)*.004))}lastX=e.clientX;lastY=e.clientY});['pointerup','pointercancel'].forEach(e=>renderer.domElement.addEventListener(e,()=>{lastX=null;lastY=null}));
document.querySelector('#play').onclick=async()=>{try{if(screen.orientation&&screen.orientation.lock)await screen.orientation.lock('landscape')}catch(e){} playing=true;document.querySelector('#start').style.display='none';status.textContent='Cari 3 kunci dan hindari Hanako serta Hikari!';};
document.querySelector('#flash').onclick=()=>{flash=!flash;document.querySelector('#flash').textContent='SENTER: '+(flash?'ON':'OFF')};
document.querySelector('#hide').onclick=()=>{
 hidden=!hidden;
 document.querySelector('#hide').textContent=hidden?'KELUAR SEMBUNYI':'SEMBUNYI';
 if(hidden){move={f:false,b:false,l:false,r:false};searchUntil=performance.now()+4500;status.textContent='Kamu bersembunyi. Ako akan mencari posisi terakhirmu…';}
 else {lastKnown={x:px,z:pz};status.textContent='Kamu keluar dari persembunyian!';}
};
function message(t){let m=document.querySelector('#msg');m.replaceChildren();m.style.display='block';const label=document.createElement('div');label.textContent=t;m.appendChild(label);let b=document.createElement('button');b.textContent='ULANGI';b.style.display='block';b.style.margin='12px auto';b.style.padding='8px 18px';b.style.fontSize='20px';b.style.pointerEvents='auto';b.style.touchAction='manipulation';b.onclick=(e)=>{e.preventDefault();e.stopPropagation();location.reload()};m.appendChild(b)}
function blocked(x,z){if(!collisionRoot)return false;const p=new THREE.Vector3(x,0,z);let hit=false;collisionRoot.traverse(n=>{if(!n.isMesh||!n.visible)return;const b=new THREE.Box3().setFromObject(n);if(b.max.y<.15||b.min.y>2.4)return;if(p.x>b.min.x-.3&&p.x<b.max.x+.3&&p.z>b.min.z-.3&&p.z<b.max.z+.3)hit=true});return hit}
function findPath(sx,sz,tx,tz){
 const cell=1, minX=-20,maxX=20,minZ=-30,maxZ=22;
 const cols=Math.round((maxX-minX)/cell),rows=Math.round((maxZ-minZ)/cell);
 const key=(x,z)=>x+','+z, toGrid=(x,z)=>({x:Math.max(0,Math.min(cols,Math.round(x-minX))),z:Math.max(0,Math.min(rows,Math.round(z-minZ)))});
 const from=toGrid(sx,sz),to=toGrid(tx,tz),pos=n=>({x:minX+n.x*cell,z:minZ+n.z*cell});
 const start={...from,g:0,f:0,parent:null},open=[start],best=new Map([[key(from.x,from.z),start]]),closed=new Set();
 let found=null,steps=0;
 while(open.length&&steps++<3500){
  open.sort((a,b)=>a.f-b.f);const cur=open.shift(),ck=key(cur.x,cur.z);
  if(closed.has(ck))continue;closed.add(ck);
  if(Math.hypot(cur.x-to.x,cur.z-to.z)<=1.4){found=cur;break;}
  for(const [dx,dz] of [[1,0],[-1,0],[0,1],[0,-1],[1,1],[1,-1],[-1,1],[-1,-1]]){
   const x=cur.x+dx,z=cur.z+dz;if(x<0||x>cols||z<0||z>rows)continue;
   const pp=pos({x,z});if(blocked(pp.x,pp.z))continue;
   if(dx&&dz&& (blocked(pp.x,pos(cur).z)||blocked(pos(cur).x,pp.z)))continue;
   const g=cur.g+(dx&&dz?1.414:1),k=key(x,z),old=best.get(k);
   if(!old||g<old.g){const n={x,z,g,f:g+Math.hypot(x-to.x,z-to.z),parent:cur};best.set(k,n);open.push(n);}
  }
 }
 if(!found)return [];
 const out=[];while(found.parent){out.unshift(pos(found));found=found.parent;}return out;
}
function animate(){requestAnimationFrame(animate);const dt=Math.min(clock.getDelta(),.05);if(playing&&!dead&&!won){if(flash)battery=Math.max(0,battery-dt*.65);if(battery<=0)flash=false;document.querySelector('#battery').textContent='SENTER '+Math.round(battery)+'%';let s=dt*3.2,dx=0,dz=0;if(move.f){dx-=Math.sin(yaw)*s;dz-=Math.cos(yaw)*s}if(move.b){dx+=Math.sin(yaw)*s;dz+=Math.cos(yaw)*s}if(move.l){dx-=Math.cos(yaw)*s;dz+=Math.sin(yaw)*s}if(move.r){dx+=Math.cos(yaw)*s;dz-=Math.sin(yaw)*s}if(!hidden){if(!blocked(px+dx,pz))px+=dx;if(!blocked(px,pz+dz))pz+=dz;lastKnown={x:px,z:pz};}for(let i=0;i<3;i++){keyMeshes[i].rotation.y+=dt*1.5;if(!got[i]&&Math.hypot(px-keys[i].x,pz-keys[i].z)<.8){got[i]=true;scene.remove(keyMeshes[i]);document.querySelector('#keys').textContent='KUNCI '+got.filter(Boolean).length+'/3'}}if(got.every(Boolean)&&Math.hypot(px,pz+29)<2.0){won=true;message('KAMU BERHASIL KELUAR!')}enemies.forEach(e=>{if(e.mixer)e.mixer.update(dt);});
// AI: masing-masing hantu berpatroli, mendeteksi player di depan, lalu mengejar lewat jalur yang tidak menembus dinding.
function canSeeEnemy(e,dx,dz,distance){
 if(distance>e.detectRange)return false;
 const forward=new THREE.Vector3(Math.sin(e.root.rotation.y),0,Math.cos(e.root.rotation.y));
 const toPlayer=new THREE.Vector3(dx,0,dz).normalize();
 // Saat sedang berpatroli, gunakan bidang pandang; saat player berlari dekat, pendengaran juga dapat menarik perhatian.
 const inFront=forward.dot(toPlayer)>Math.cos(e.detectAngle/2);
 if(!inFront && distance>3.2)return false;
 const steps=Math.ceil(distance/.45);
 for(let i=1;i<steps;i++){const t=i/steps;if(blocked(e.root.position.x+dx*t,e.root.position.z+dz*t))return false;}
 return true;
}
function chooseEnemyTarget(e,dt){
 const root=e.root,dx=px-root.position.x,dz=pz-root.position.z,d=Math.hypot(dx,dz),now=performance.now();
 const visible=!hidden&&canSeeEnemy(e,dx,dz,d);
 if(visible){e.alert=true;e.lastSeen={x:px,z:pz};e.searchUntil=now+4200;}
 else if(e.alert&&now>e.searchUntil)e.alert=false;
 let tx,tz;
 if(e.alert){tx=e.lastSeen.x;tz=e.lastSeen.z;}
 else {const target=e.patrol[e.patrolIndex%e.patrol.length]||[0,0];tx=target[0];tz=target[1];if(Math.hypot(tx-root.position.x,tz-root.position.z)<1.0){e.patrolIndex=(e.patrolIndex+1)%e.patrol.length;e.pathTimer=0;}}
 e.pathTimer-=dt;
 if(e.pathTimer<=0||!e.path.length){e.path=findPath(root.position.x,root.position.z,tx,tz);e.pathTimer=.65;if(!e.path.length){e.patrolIndex=(e.patrolIndex+1)%e.patrol.length;}}
 let moving=false;
 if(e.path.length){let wp=e.path[0],wx=wp.x-root.position.x,wz=wp.z-root.position.z,wd=Math.hypot(wx,wz);if(wd<.5){e.path.shift();if(e.path.length){wp=e.path[0];wx=wp.x-root.position.x;wz=wp.z-root.position.z;wd=Math.hypot(wx,wz);}}
  if(wd>.001){const speed=e.alert?e.speed*1.35:e.speed*.62;let step=Math.min(speed*dt,wd);/* Jangan biarkan model masuk ke kamera/player: berhenti pada jarak aman. */if(e.alert)step=Math.min(step,Math.max(0,d-1.8));if(step>0.001){const nx=root.position.x+wx/wd*step,nz=root.position.z+wz/wd*step;if(!blocked(nx,root.position.z))root.position.x=nx;if(!blocked(root.position.x,nz))root.position.z=nz;root.rotation.y=Math.atan2(wx,wz);moving=true;}}}
 if(e.mixer&&e.idle&&e.walk&&e.capture){const caught=!hidden&&d<1.85;const target=caught?e.capture:(moving?e.walk:e.idle);if(e.current!==target){e.current.stop();target.reset();target.enabled=true;target.setEffectiveWeight(1);target.play();e.current=target;}e.idle.setEffectiveWeight(target===e.idle?1:0);e.walk.setEffectiveWeight(target===e.walk?1:0);e.capture.setEffectiveWeight(target===e.capture?1:0);}
 if(!hidden&&d<1.85){dead=true;playing=false;message(e.name.toUpperCase()+' MENANGKAPMU!');}
}
enemies.forEach(e=>{if(e.ready&&e.root&&!dead&&!won)chooseEnemyTarget(e,dt);});
}
camera.position.set(px,1.65,pz);camera.rotation.order='YXZ';camera.rotation.set(pitch,yaw,0);playerLight.position.copy(camera.position);const dir=new THREE.Vector3(0,0,-1).applyQuaternion(camera.quaternion);playerLight.target.position.copy(camera.position).add(dir.multiplyScalar(5));playerLight.intensity=flash?55:0;renderer.render(scene,camera)}
const clock=new THREE.Clock();animate();addEventListener('resize',()=>{camera.aspect=innerWidth/innerHeight;camera.updateProjectionMatrix();renderer.setSize(innerWidth,innerHeight)});
