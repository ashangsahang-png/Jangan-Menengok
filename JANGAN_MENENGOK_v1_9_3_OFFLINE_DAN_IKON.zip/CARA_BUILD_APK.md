# JANGAN MENENGOK v1.9.3 — Offline + Ikon

Versi ini menyertakan Three.js dan GLTFLoader secara lokal saat proses build sehingga game tidak perlu mengunduh library 3D dari CDN ketika dimainkan. Audio dan model game juga disimpan di folder assets.

## GitHub
Unggah isi ZIP ini ke repository (ganti file lama dengan versi ini). Pastikan `.github/workflows/android-apk.yml` berada di jalur tersebut. Lalu buka Actions → Build JANGAN MENENGOK APK → Run workflow.

Ikon khusus berada di `resources/icon.png`; workflow menjalankan `npx capacitor-assets generate --android` sebelum membangun APK.

Jika workflow lama masih ada di repository, ganti file `.github/workflows/android-apk.yml` dengan versi yang ada di ZIP ini. Jangan hanya mengunggah ZIP sebagai satu file.
