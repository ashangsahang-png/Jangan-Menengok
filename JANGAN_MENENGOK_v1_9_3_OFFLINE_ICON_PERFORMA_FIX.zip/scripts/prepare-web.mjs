import fs from 'node:fs';
import path from 'node:path';

const root = process.cwd();
const out = path.join(root, 'www');
fs.rmSync(out, { recursive: true, force: true });
fs.mkdirSync(out, { recursive: true });

for (const name of ['index.html', 'assets']) {
  const from = path.join(root, name);
  if (!fs.existsSync(from)) throw new Error(`Missing required project item: ${name}`);
  fs.cpSync(from, path.join(out, name), { recursive: true });
}

const threeRoot = path.join(root, 'node_modules', 'three');
const vendor = path.join(out, 'vendor');
fs.mkdirSync(vendor, { recursive: true });
fs.copyFileSync(path.join(threeRoot, 'build', 'three.module.js'), path.join(vendor, 'three.module.js'));
fs.cpSync(path.join(threeRoot, 'examples', 'jsm'), path.join(vendor, 'examples', 'jsm'), { recursive: true });

console.log('Prepared local Three.js modules and game assets in www/');
