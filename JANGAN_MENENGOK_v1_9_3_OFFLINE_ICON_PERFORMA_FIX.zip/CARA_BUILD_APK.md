# JANGAN MENENGOK v1.9.3 — Offline + Ikon + Performa HP

Perbaikan ini:
- Mengimpor Three.js dari dependency lokal (`import * as THREE from 'three'`), bukan CDN.
- Menyalin Three.js dan GLTFLoader ke `www/vendor` saat build.
- Menurunkan beban GPU di HP: antialias dimatikan, pixel ratio dibatasi 1.0, shadow mapping dimatikan.
- Menyertakan konfigurasi pembuatan ikon Android dari `resources/icon.png`.

PENTING: ekstrak ZIP ini dan unggah ISI foldernya ke repository GitHub; jangan hanya unggah ZIP sebagai satu file. Timpa file lama, termasuk `index.html`, `package.json`, `scripts/prepare-web.mjs`, dan `.github/workflows/android-apk.yml`.

Lalu Actions → Build JANGAN MENENGOK APK → Run workflow. APK belum dibangun atau diuji langsung di perangkat pada saat ZIP ini dibuat.
